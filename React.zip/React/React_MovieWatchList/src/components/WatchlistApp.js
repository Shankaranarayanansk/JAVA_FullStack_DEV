import React from "react";
import MovieCard from "./MovieCard";
import Watchlist from "./Watchlist";

const movies = [
  { id: 1, title: "Inception" },
  { id: 2, title: "Interstellar" },
  { id: 3, title: "The Dark Knight" },
  { id: 4, title: "Dunkirk" },
  { id: 5, title: "The Shawshank Redemption" },
];

const WatchlistApp = () => {
  return (
    <div>
      <h2>Movies</h2>
      <div className="movies-container">
        <MovieCard />
      </div>

      <Watchlist />
    </div>
  );
};

export default WatchlistApp;
