function ExpenseForm() {
  return (
    <>
        <label htmlFor="income">Add Expense:</label> <br/>
        <input type="number" id="expense" name="income" />
        <button type="submit">Submit</button>
    </>
  );
}
export default ExpenseForm