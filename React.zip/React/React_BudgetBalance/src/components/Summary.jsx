import React from "react";

const Summary = () => {

  return (
    <div >
      <h2 >Summary</h2>
      <div><p>Total Income: </p></div>


      <div >
        <p>Total Expenses: </p>
      </div>

      <div >
        <p>Balance: </p>
      </div>

      <button > Reset</button>
    </div>
  );
};
export default Summary;
