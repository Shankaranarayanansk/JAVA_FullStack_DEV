function IncomeForm() {
  return (
    <>
        <label htmlFor="income">Add Income:</label> <br/>
        <input type="number" id="income" name="income" />
        <button type="submit">Submit</button>
    </>
  );
}
export default IncomeForm