import ExpenseForm from "./ExpenseForm";
import IncomeForm from "./IncomeForm";
import Summary from "./Summary.jsx";

function BudgetTracker() {
  return (
    <>
     <IncomeForm />
     <br />
     <ExpenseForm />
     <Summary />
    </>
  );
}
export default BudgetTracker
