import { useState } from 'react'
import './App.css'
import BudgetTracker from './components/BudgetTracker'

function App() {

  return (
    <>
     <BudgetTracker />
    </>
  )
}

export default App
