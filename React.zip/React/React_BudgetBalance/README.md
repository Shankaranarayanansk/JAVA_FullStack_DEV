In this application, the task is to build a budget tracker that helps users manage their income and expenses effectively. Edit the
BudgetTracker.js,
IncomeForm.js,
ExpenseForm.js and
Summary,js
components within the project structure to ensure the application functions as described below:

Functionality Requirements:

1.  Initial State of the project:
    The income and expense input fields should be empty and must have the attribute type as number.
    Ensure that the total income, total expenses, and balance are initialized to 0.

2.  Validation:
    Positive Numbers Only:
    The income and expense values must be positive. Negative or zero values should not be added.
    Empty Input Handling:
    No update to the total income, expense and balance, if non-positive income or expense is added.

3.  Income and Expense Functionality:
    Add Income: When the user enters a positive number in the income input box and clicks the "Add" button:
    The value is added to the total income.
    The balance is updated as total income - total expenses.
    The income input box is cleared.
    Add Expense: When the user enters a positive number in the expense input box and clicks the "Add" button:
    The value is added to the total expenses.
    The balance is updated as total income - total expenses.
    The expense input box is cleared.

4.  Reset Functionality:
    Add a "Reset" button which resets the Total Income, Total Expenses, and Balance to 0.
    Clicking the "Reset" button ensures the application returns to its initial state.
    Question - 4
    React: Budget Balance Assistant

Note:
The following data-testid attributes are required in the components for the test cases to pass, do not change/delete them:
Table of data-testid
data-testid / Description
income-input / Input box to enter the income amount.
add-income-btn / Button to add the entered income.
expense-input / Input box to enter the expense amount.
add-expense-btn / Button to add the entered expense.
total-income / Text displaying the total income value.
total-expenses / Text displaying the total expenses value.
balance / Text displaying the current balance (income-expense).
reset-btn / Button to reset the income, expense, and balance.
