package com.js.model_entity_validation.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.js.model_entity_validation.entity.Store;
import com.js.model_entity_validation.services.StoreService;

@RestController
@RequestMapping("/stores")
public class StoreController {
	@Autowired
	StoreService storeService;
	
	@PostMapping
	public Store createStore(@RequestBody StoreDTO storeDTO) {
		return storeService.createStore(storeDTO);
		
	}
	
	@GetMapping("/{id}")
	public Store getStore(@PathVariable Long id) {
		return storeService.getStore(id);
		
	}


}
