package com.js.model_entity_validation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.js.model_entity_validation.controllers.StoreDTO;
import com.js.model_entity_validation.entity.Store;
import com.js.model_entity_validation.repositories.StoreRepository;

@Service
public class StoreService {

	@Autowired
	StoreRepository storeRepository;
	
	public Store createStore(StoreDTO storeDTO) {
		Store store = new Store();
		store.setName(storeDTO.getName());
		store.setAddress(storeDTO.getAddress());
		return storeRepository.save(store);
	}

	public Store getStore(Long id) {
		return storeRepository.findById(id).get();
	}

}
