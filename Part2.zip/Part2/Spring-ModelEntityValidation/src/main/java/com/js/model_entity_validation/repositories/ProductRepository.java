package com.js.model_entity_validation.repositories;

import org.springframework.stereotype.*;
import com.js.model_entity_validation.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ProductRepository extends JpaRepository<Product,Long>{

}
