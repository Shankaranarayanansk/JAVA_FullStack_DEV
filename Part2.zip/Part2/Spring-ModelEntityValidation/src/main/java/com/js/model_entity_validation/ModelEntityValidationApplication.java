package com.js.model_entity_validation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelEntityValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelEntityValidationApplication.class, args);
	}

}
