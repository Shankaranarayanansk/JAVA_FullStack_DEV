package com.js.model_entity_validation.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.js.model_entity_validation.controllers.ProductDTO;
import com.js.model_entity_validation.entity.Product;
import com.js.model_entity_validation.entity.Store;
import com.js.model_entity_validation.repositories.ProductRepository;
import com.js.model_entity_validation.repositories.StoreRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private StoreRepository storeRepository;

	public List<Product> getProducts() {
		return productRepository.findAll();
	}

	public Product createProduct(ProductDTO productDTO) {
		Product product = new Product();
		product.setName(productDTO.getName());
		product.setDescription(productDTO.getDescription());
		product.setPrice(productDTO.getPrice());
		Store store = storeRepository.findById((long)productDTO.getStoreId().intValue()).get();
		product.setStore(store);
		return productRepository.save(product);
	}
	
	
}
