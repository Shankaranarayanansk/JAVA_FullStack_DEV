package com.js.model_entity_validation.repositories;

import org.springframework.stereotype.*;
import com.js.model_entity_validation.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface StoreRepository extends JpaRepository<Store,Long>{

}
