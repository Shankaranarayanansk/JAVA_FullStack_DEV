package com.js.model_entity_validation.controllers;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.js.model_entity_validation.entity.*;
import com.js.model_entity_validation.repositories.ProductRepository;
import com.js.model_entity_validation.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@GetMapping("/all")
	public List<Product> getProducts(){
		return productService.getProducts();
	}
	
	@PostMapping
	public Product createProduct(@RequestBody ProductDTO productDTO) {
		return productService.createProduct(productDTO);
	}
}
