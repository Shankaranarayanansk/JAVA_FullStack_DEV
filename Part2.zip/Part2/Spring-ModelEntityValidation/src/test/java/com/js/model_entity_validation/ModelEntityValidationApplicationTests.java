package com.js.model_entity_validation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelEntityValidationApplicationTests {

	//@Test
	void contextLoads() {
	}

}
